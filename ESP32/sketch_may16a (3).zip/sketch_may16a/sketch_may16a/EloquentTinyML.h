#ifndef ELOQUENT_TINYML_H
#define ELOQUENT_TINYML_H

#include "eloquent_tinyml_internal/tiny_model.h"

namespace Eloquent {
    namespace TinyML {
        template<int N_INPUTS, int N_OUTPUTS, int ARENA_SIZE>
        using TfLite = Eloquent::TinyML::Internal::TinyModel<N_INPUTS, N_OUTPUTS, ARENA_SIZE>;
    }
}

#endif
