
#ifndef TENSORFLOW_LITE_MICRO_ALL_OPS_RESOLVER_H_
#define TENSORFLOW_LITE_MICRO_ALL_OPS_RESOLVER_H_

namespace tflite {

class AllOpsResolver {
public:
    AllOpsResolver() {}
};

}  // namespace tflite

#endif  // TENSORFLOW_LITE_MICRO_ALL_OPS_RESOLVER_H_
