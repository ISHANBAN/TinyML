
#ifndef MODEL_H
#define MODEL_H\

#include <pgmspace.h>

extern const unsigned char model_tflite[] PROGMEM;
extern const int model_tflite_len;

#endif
