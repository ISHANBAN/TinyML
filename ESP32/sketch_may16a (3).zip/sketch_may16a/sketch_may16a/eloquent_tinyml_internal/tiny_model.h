#ifndef TINY_MODEL_H
#define TINY_MODEL_H

#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/version.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include <esp_heap_caps.h>

namespace Eloquent {
    namespace TinyML {
        namespace Internal {

            using namespace tflite;

            template<int N_INPUTS, int N_OUTPUTS, int ARENA_SIZE>
            class TinyModel {
            public:
                MicroInterpreter* interpreter = nullptr;
                TfLiteTensor* input;
                float output[N_OUTPUTS];

                uint8_t* tensor_arena;
                const Model* model;
                MicroMutableOpResolver<10> resolver;

                void begin(const unsigned char* model_data) {
                    Serial.println("Allocating tensor arena in PSRAM...");
                    tensor_arena = (uint8_t*) ps_malloc(ARENA_SIZE);
                    if (tensor_arena == nullptr) {
                        Serial.println("ERROR: Failed to allocate tensor arena in PSRAM.");
                        return;
                    }

                    model = GetModel(model_data);

                    resolver.AddFullyConnected();
                    resolver.AddReshape();
                    resolver.AddSoftmax();
                    resolver.AddQuantize();
                    resolver.AddDequantize();
                    resolver.AddTranspose();  // ✅ THIS IS THE FIX
                    resolver.AddConv2D();          // ✅ NEW
                    interpreter = new MicroInterpreter(
                        model,
                        resolver,
                        tensor_arena,
                        ARENA_SIZE,
                        nullptr,
                        nullptr,
                        false
                    );

                    Serial.println("Allocating tensors...");
                    TfLiteStatus alloc_status = interpreter->AllocateTensors();
                    if (alloc_status != kTfLiteOk) {
                        Serial.println("ERROR: Tensor allocation failed.");
                        interpreter = nullptr;
                        return;
                    }

                    input = interpreter->input(0);
                    Serial.println("Model initialized successfully.");
                }

                float* predict(float* input_data) {
                    if (!interpreter) return nullptr;
                    for (int i = 0; i < N_INPUTS; i++) input->data.f[i] = input_data[i];
                    if (interpreter->Invoke() != kTfLiteOk) return nullptr;
                    TfLiteTensor* output_tensor = interpreter->output(0);
                    for (int i = 0; i < N_OUTPUTS; i++) output[i] = output_tensor->data.f[i];
                    return output;
                }
            };
        }
    }
}
#endif
